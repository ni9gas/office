import React from "react";

import Live from "./live";

interface AnyOtherEmailProps {}

const AnyOtherEmail: React.FC<AnyOtherEmailProps> = () => {
  return <Live />;
};

export default AnyOtherEmail;
